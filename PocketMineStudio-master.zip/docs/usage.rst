========
Usage
========

To use this template, simply update it::

	import read-the-docs-template
